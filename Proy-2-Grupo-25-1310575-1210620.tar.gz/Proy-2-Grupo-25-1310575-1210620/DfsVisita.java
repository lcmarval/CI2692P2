/**
 * DfsVisita.java
 * Autores: 
 * @author Pablo González. Carnet: 13-10575
 * @author Luis Marval. Carnet: 12-10620
 */

import java.util.*;

public class DfsVisita{
	public Hashtable<String,String> p;  // id, id
	public Hashtable<String,String> color;  // id, color
	private int suma;
	private LinkedList<Vertice> alturas;	// lista para medir alturas


/** 
 * DfsVisita:
 * Inicializa la clase DfsVisita, crea las tablas de Hash (p,color)
*/ 
	public DfsVisita(){
		p = new Hashtable<String,String>();
		color = new Hashtable<String,String>();
		alturas = new LinkedList<Vertice>(); 
		suma = 0;

	}
/** 
 * llamadaDfsV1:
 * llama a la funcion DfsV1 en todos los vertices
 * Parametros de entrada: 
 * @param Grafo g(V,E)
 * Parametros de salida:
 * @throws void: vacio
*/ 
	public void llamadaDfsV1(Grafo g){
		// inicializacion tablas
		for (Vertice v : g.vertices()){
			color.put(v.getId(), "blanco");
			p.put(v.getId(), "-");
		}
		// llamada DfsV1
		for (Vertice v : g.vertices()){
			if (color.get(v.getId()).equals("blanco")){
				DfsV1(v); 
			}
		}
	}

/** 
 * DfsV1:
 * funcion DfsV que visita visita los vertices alcanzables por v. Actividad 1
 * Parametros de entrada: 
 * @param Vertice v
 * Parametros de salida:
 * @throws p: Tabla de Hash
 * @throws color: Tabla de Hash
*/ 
	public String DfsV1(Vertice v){

		if (v.getEstado().equals("0")){
			return v.getEstado();
		}
		color.put(v.getId(), "gris");
		String estadoActual = v.getEstado();
		for (Vertice w : v.predecesores){
			if (color.get(w.getId()).equals("blanco")){
				p.put(w.getId(), v.getId());
				estadoActual = (DfsV1(w));
				if (estadoActual.equals("0")){
					break;
				}
			}
			if(w.getEstado().equals("x") && w.getAltura() < v.getAltura()){
				v.setEstado("0");
			}
		}

		if (v.getEstado().equals("x")){
			v.setEstado(estadoActual);
		}
		color.put(v.getId(), "negro");
		return v.getEstado();
	}

/** 
 * llamadaDfsV2:
 * llama a la funcion DfsV2 en todos los vertices. 
 * Parametros de entrada: 
 * @param Grafo g(V,E)
 * Parametros de salida:
 * @throws void: vacio
*/ 
	public void llamadaDfsV2(Grafo g){
		// inicializacion tablas
		for (Vertice v : g.vertices()){
			color.put(v.getId(), "blanco");
			p.put(v.getId(), "-");
		}
		// llamada DfsV2
		for (Vertice v : g.vertices()){
			if (color.get(v.getId()).equals("blanco")){
				DfsV2(v); 
			}
		}
		
		if (!alturas.isEmpty()){
			System.out.println(alturas);
			int mayorInm = Integer.MAX_VALUE;
			for (Vertice w: alturas){
				for (Vertice u: w.sucesores){
					if (u.getAltura() < mayorInm && u.getEstado().equals("0")){
						System.out.println(u.getAltura());
						mayorInm = u.getAltura();
					}
				}
			}
			System.out.println(" MA alto menor:" + String.valueOf(mayorInm));
			for(Vertice z: alturas){
				suma = suma + (mayorInm - z.getAltura());
			}
			alturas.clear();
		}
	}

/** 
 * DfsV2:
 * funcion DfsV que visita visita los vertices alcanzables por v. Actividad 2
 * Parametros de entrada: 
 * @param Vertice v
 * Parametros de salida:
 * @throws p: Tabla de Hash
 * @throws color: Tabla de Hash
*/ 
	public String DfsV2(Vertice v){

		if (v.getEstado().equals("0")){
			return v.getEstado();
		}
		color.put(v.getId(), "gris");
		String estadoActual = v.getEstado();
		for (Vertice w : v.predecesores){
			if (color.get(w.getId()).equals("blanco")){
				p.put(w.getId(), v.getId());
				estadoActual = (DfsV2(w));
				if (estadoActual.equals("0")){
					v.setEstado(estadoActual);
					break;
				}
			}
		}

		if (v.getEstado().equals("x")){
			v.setEstado(estadoActual);
			alturas.add(v);
		}
		color.put(v.getId(), "negro");
		return v.getEstado();
	}

/** 
 * obtenerPre:
 * funcion que retorna los predecesores
 * Parametros de entrada: 
 * void
 * Parametros de salida:
 * @throws p: Tabla de Hash
*/ 
	public Hashtable<String, String> obtenerPre(){
		return p;
	}

/** 
 * obtenerPre:
 * funcion que retorna los predecesores
 * Parametros de entrada: 
 * void
 * Parametros de salida:
 * @throws p: Tabla de Hash
*/ 
	public int suma(){
		return suma;
	}

/** 
 * obtenerColor:
 * funcion que retorna los predecesores
 * Parametros de entrada: 
 * void
 * Parametros de salida:
 * @throws color: Tabla de Hash
*/ 
	public Hashtable<String, String> obtenerColor(){
		return color;
	}
	
}